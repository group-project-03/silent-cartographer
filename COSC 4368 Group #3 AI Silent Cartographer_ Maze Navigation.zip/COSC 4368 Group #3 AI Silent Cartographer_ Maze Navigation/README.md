# Requirements:
- Python >= 3.7
- NumPy
- Pillow (PIL)
- Matplotlib 
- PyTorch

# Run the script:
	python silent_cartographer.py

# Input:
-program will ask "Enter maze image:"
Input examples: 
gama_1.png
MAZE_1.png
alpha_1.png